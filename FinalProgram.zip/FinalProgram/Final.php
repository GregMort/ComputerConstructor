<?php
include 'dbConnection.php';  // includes the connection file to connect to the db
include 'header.php'; // includes header to start session

// requires inputs for form to not error
if (isset($_SESSION['validated']) && $_SESSION['validated']) {
$formErrors = "";
$requiredInputs = ['gaming', 'size','form_factor'];

//validates that there are inputs
function testInput($input) {
	if (!isset($_POST[$input])) {
		return $input . " is required<br>";
	}
}

function storeInput($gaming,$size,$formFactor)  {
	// Create connection and...
	$conn = new DatabaseConnect();
	if ($conn) {
		$bGaming = 'false';
		if ($gaming === 'yes') {
			$bGaming = 'true';
		}
		// converting yes/no to true/false
		$sqlOutcome = "SELECT id FROM outcomes WHERE gaming = " . $bGaming . " AND form_factor = '" . $formFactor . "' AND size = '" . $size . "';";
        // get the results url based on the user input from the database
		$exec = $conn->executeQuery($sqlOutcome);
		$results = $exec->fetch_assoc();
		// storing the form submission into the database with reference to the outcome as the result
		$sql  = "INSERT INTO form_submissions (gaming, size,form_factor, outcome_id)
				 VALUES ('" . $gaming . "','" . $size . "','" . $formFactor . "'," . $results['id'] . ")";
        //using dbconnection to execute query and close the connection
		$conn->executeQuery($sql);
		$conn->closeConnection();
		header("Location: list.php");
	} 
}
// check to see if form was submitted based on if it was posted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
	foreach ($requiredInputs as $required) {
		$formErrors .= testInput($required);
	}
	//call test inputs to make sure all required fields are requested
	if (!$formErrors) {
		storeInput($_POST['gaming'],$_POST['size'],$_POST['form_factor']); // calling the function
	}
}
?>
<!-- creates the form for the user to answer the questions and then submit-->
<form action="#" method="post">
  <span class="error"><?php echo $formErrors;?> </span>
Are you using this PC for gaming? <span class="error">* </span>
<input type="radio" name="gaming" value="yes">Yes
<input type="radio" name="gaming" value="no">No<br>

Do you prefer a laptop or desktop? <span class="error">*</span>
<input type="radio" name="form_factor" value="desktop">Desktop
<input type="radio" name="form_factor" value="laptop">Laptop<br>

Do you prefer a large or small Computer? <span class="error">*</span>
<input type="radio" name="size" value="small">Small
<input type="radio" name="size" value="large">Large<br><br>


<input type="submit" name="submit" value="Submit">

</form>

<?php
// provides a link for the user to go back to login if not logged in
} else {
	echo "You are unauthorized to view this page<br>";
	echo '<a href="index.php">Go to login page</a>';
}
// includes footer to provide logout link
include 'footer.php';
?>