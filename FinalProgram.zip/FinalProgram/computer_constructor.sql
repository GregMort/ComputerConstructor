-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2019 at 04:06 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `computer_constructor`
--
CREATE DATABASE IF NOT EXISTS `computer_constructor` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `computer_constructor`;

-- --------------------------------------------------------

--
-- Table structure for table `form_submissions`
--

DROP TABLE IF EXISTS `form_submissions`;
CREATE TABLE `form_submissions` (
  `id` int(11) NOT NULL,
  `gaming` enum('yes','no') NOT NULL,
  `size` enum('small','large') NOT NULL,
  `form_factor` enum('desktop','laptop') NOT NULL,
  `outcome_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `outcomes`
--

DROP TABLE IF EXISTS `outcomes`;
CREATE TABLE `outcomes` (
  `id` int(11) NOT NULL,
  `gaming` tinyint(1) NOT NULL,
  `form_factor` enum('desktop','laptop') NOT NULL,
  `size` enum('small','large') NOT NULL,
  `url` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `outcomes`
--

INSERT INTO `outcomes` (`id`, `gaming`, `form_factor`, `size`, `url`) VALUES
(1, 1, 'desktop', 'small', 'https://www.newegg.com/Product/Product.aspx?Item=N82E16856102201&ignorebbr=1'),
(2, 1, 'desktop', 'large', 'https://www.newegg.com/Product/Product.aspx?Item=N82E16883227885'),
(3, 1, 'laptop', 'small', 'https://www.newegg.com/Product/Product.aspx?Item=N82E16834326063&Description=razer%20blade%20stealth&cm_re=razer_blade_stealth-_-34-326-063-_-Product'),
(4, 1, 'laptop', 'large', 'https://www.newegg.com/Product/Product.aspx?Item=N82E16834326068&Description=razer%20blade&cm_re=razer_blade-_-34-326-068-_-Product'),
(5, 0, 'desktop', 'small', 'https://www.newegg.com/Product/Product.aspx?Item=1JW-000K-00341&ignorebbr=1'),
(6, 0, 'desktop', 'large', 'https://www.newegg.com/Product/Product.aspx?Item=9SIAD6H85X2475&Description=ThinkCentre&cm_re=ThinkCentre-_-9SIAD6H85X2475-_-Product'),
(7, 0, 'laptop', 'small', 'https://www.newegg.com/Product/Product.aspx?Item=9SIA24G94P6130&Description=ThinkPad&cm_re=ThinkPad-_-34-331-940-_-Product'),
(8, 0, 'laptop', 'large', 'https://www.newegg.com/Product/Product.aspx?Item=9SIA7AB8AG8402&Description=ThinkPad&cm_re=ThinkPad-_-9SIA7AB8AG8402-_-Product');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form_submissions`
--
ALTER TABLE `form_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_outcomes_form-submissions` (`outcome_id`);

--
-- Indexes for table `outcomes`
--
ALTER TABLE `outcomes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form_submissions`
--
ALTER TABLE `form_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `outcomes`
--
ALTER TABLE `outcomes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `form_submissions`
--
ALTER TABLE `form_submissions`
  ADD CONSTRAINT `fk_outcomes_form-submissions` FOREIGN KEY (`outcome_id`) REFERENCES `outcomes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
