<?php
	class DatabaseConnect {
		private $dbConnection = null;
		// provides the information to connect to the db
		public function __construct()  {
			$db_host = 'localhost';
			$db_username = 'root';
			$db_password = '';
			$db_name = 'computer_constructor';
			//connection error message incase connection fails
			$conn = new mysqli($db_host, $db_username, $db_password, $db_name);
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} else {
				$this->dbConnection = $conn;
			}
		}
		
		public function executeQuery($sql) {
			 return $this->dbConnection->query($sql);
		}
		
		public function closeConnection() {
			$this->dbConnection->close();
		}
	}
?>