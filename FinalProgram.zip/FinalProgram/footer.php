</body>
</html>
<!-- provides logout link to redirect to login-->
<a href="logout.php">Logout</a>