<?php
// starts session
session_start();
?>
<html>
<head>
<style>
.error {color: red;}
</style>
</head>

