<?php
//includes header to establish connection
include 'header.php';
//if posts, validates username and password
if ($_SERVER["REQUEST_METHOD"] === "POST") {
	if ($_POST['username'] === $_SESSION["username"] // username: testing
		&& $_POST['password'] === $_SESSION["password"]) { // password: testing
			$_SESSION["validated"] = true;
			header("Location: list.php");
			die();
		} else {
			echo "Wrong credentials: please try again";
		}
} else {
	$_SESSION["username"] = "testing";
	$_SESSION["password"] = "testing";
	$_SESSION["validated"] = false;
}
$formErrors = "";
?>

<!-- provides text box's for username and password -->
<form action="#" method="post">
  <span class="error"><?php echo $formErrors;?> </span>
Username:  <span class="error">* </span>
<input type="text" name="username"></input><br>


Password: <span class="error">*</span>
<input type="text" name="password"></input><br><br>
<input type="submit" name="submit" value="Submit">
</form>

<?php
//includes footer to provide logout link
include 'footer.php';
?>