<?php
include 'dbConnection.php';
include 'header.php';
if (isset($_SESSION['validated']) && $_SESSION['validated']) {
// Create connection
$conn = new DatabaseConnect();

// Check connection
if ($conn) {
	$sql = "SELECT form_submissions.*, outcomes.url
			FROM form_submissions
			left outer join outcomes on form_submissions.outcome_id = outcomes.id
			ORDER BY form_submissions.id DESC";
	$result = $conn->executeQuery($sql);


	//displaying all results from database form submissions
	if ($result->num_rows > 0) {
		echo '<table>';
		echo '<tr>';
		echo '<th>Result Number</th>';
		echo '<th>Gaming</th>';
		echo '<th>Form Factor</th>';
		echo '<th>Size</th>';
		echo '<th>Result</th>';
		echo '</tr>';
		while ($row = $result->fetch_assoc()) {
			echo '<tr>';
			echo '<td>' . $row["id"] . '</td>';
			echo '<td>' . $row["gaming"] . '</td>';
			echo '<td>' . $row["form_factor"] . '</td>';
			echo '<td>' . $row["size"] . '</td>';
			echo '<td>' . $row["url"] . '</td>';
			echo "</tr>";
		}
		echo '</table>';
	} else {
		echo "No Form Submissions";
	}
	
	$conn->closeConnection();
}
?>
<!-- provides link to start a new form submission-->
<a href="Final.php">Create a new computer</a>
<?php
} else {
	echo "You are unauthorized to view this page<br>";
	echo '<a href="index.php">Go to login page</a>';
}
// includes footer to provide logout link
include 'footer.php';
?>